/**
 * Interface required by all wrappers.
 */
package source;

public interface Invoker {
	public void start();	// to register this thread with the jvm.
}
