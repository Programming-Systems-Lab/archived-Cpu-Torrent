package client;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.rmi.*;

/**
 * Client to test the RMI Server for CPU Torrent
 * @author swapneelsheth
 */
public class TestRMIClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CPUTorrentRMIInterface cpu = (CPUTorrentRMIInterface) Naming.lookup("rmi://localhost:1099/CPUTorrent");
			String[] jid = new String[5];

			/**
			 * Submitting 5 fasta files for blasting.
			 */
			for (int i=0;i<=4;i++) {
				System.out.println("Sending fasta job " + (i));
				BufferedReader br = new BufferedReader(new FileReader("fasta" + (i+1) + ".f"));
				String line;
				StringBuffer sb = new StringBuffer();
				while ((line = br.readLine()) != null) {
					sb.append(line + "\n");
				}
				byte[] fastaFile = sb.toString().getBytes();
				jid[i]= cpu.submit(fastaFile);
				System.out.println("Job id:" + jid[i]);
			}
			
			// Check whether all the jobs have completed.
			
			while (true) {
				Thread.sleep(3*1000);
				/**
				 * checking status of jobs.
				 */
				int status;
				int counter = 0;
				System.out.println("------------------------------");
				for (int i=0;i<=4;i++) {
					status = cpu.getStatus(jid[i]);
					System.out.println("Status of job " + i + " is: " + status);
					if (status == source.Job.BLASTED || status == source.Job.FAILED)
						counter+=status;
				}

				if (counter == 10 || counter == 15) {
					break;
				}
			}
			
			// Get the results for the job.
			
			for (int i=0;i<=4;i++) {
				byte[] result = cpu.getResult(jid[i]);
				String name = "ClientCopy" + jid[i] + ".blastpgp";
				FileWriter fw = null;
				try {
					fw = new FileWriter(name);
					String stuff = new String(result);
					fw.write(stuff);
					fw.close();
				} catch(java.io.IOException ie) {
					System.out.println("Client: Error writing to file");
					ie.printStackTrace();
				} 
			}
			
			System.out.println("Client: Got results for all jobs");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
